SELECT 費目 FROM 家計簿
INTERSECT -- MySQLでは非対応
SELECT 費目 FROM 家計簿アーカイブ