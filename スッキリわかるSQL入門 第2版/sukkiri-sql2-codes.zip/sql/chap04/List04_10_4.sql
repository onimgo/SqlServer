-- TOPの利用（SQL Server）
SELECT TOP(3) 費目, 出金額 FROM 家計簿 ORDER BY 出金額 DESC
