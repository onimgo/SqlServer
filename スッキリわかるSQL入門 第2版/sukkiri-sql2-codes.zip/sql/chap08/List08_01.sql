UPDATE 家計簿
   SET 費目 = '給与手当'
 WHERE 費目 = '給料'