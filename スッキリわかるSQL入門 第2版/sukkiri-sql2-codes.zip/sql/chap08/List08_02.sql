UPDATE 費目
   SET 名前 = '給与手当'
 WHERE 名前 = '給料'