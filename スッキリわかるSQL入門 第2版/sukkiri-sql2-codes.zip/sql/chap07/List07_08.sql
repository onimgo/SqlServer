SELECT * FROM 家計簿
 WHERE 費目 NOT IN ('食費', '水道光熱費', NULL)