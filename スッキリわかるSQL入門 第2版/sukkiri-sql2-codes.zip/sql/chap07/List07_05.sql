SELECT * FROM 家計簿集計
 WHERE 費目 IN ('食費', '水道光熱費', '教養娯楽費', '給料')