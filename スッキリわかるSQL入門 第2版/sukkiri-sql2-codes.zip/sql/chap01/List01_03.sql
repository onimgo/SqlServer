SELECT *
  FROM 家計簿