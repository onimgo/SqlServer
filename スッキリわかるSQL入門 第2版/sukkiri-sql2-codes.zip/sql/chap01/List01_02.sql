SELECT 日付, 費目, メモ, 入金額, 出金額
  FROM 家計簿