UPDATE 家計簿 SET メモ = 'カフェラテを購入'
 WHERE 日付 = '2018-02-03'
