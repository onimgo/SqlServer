DELETE FROM 家計簿
      WHERE 日付 = '2018-02-25'
