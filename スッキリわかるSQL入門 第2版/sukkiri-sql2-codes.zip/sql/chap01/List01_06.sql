UPDATE 家計簿
   SET 出金額 = 90000
 WHERE 日付 = '2018-02-25'
