BEGIN;
INSERT INTO 家計簿
VALUES('2018-03-20', '住居費', '4月の家賃', 0, 60000);
INSERT INTO 家計簿
VALUES('2018-03-20', '手数料', '4月の家賃の振込', 0, 420);
COMMIT;
