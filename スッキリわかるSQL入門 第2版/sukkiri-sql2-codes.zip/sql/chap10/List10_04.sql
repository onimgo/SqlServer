-- 追加するとき
ALTER TABLE 家計簿 ADD 関連日 DATE;
-- 削除するとき
ALTER TABLE 家計簿 DROP 関連日;
