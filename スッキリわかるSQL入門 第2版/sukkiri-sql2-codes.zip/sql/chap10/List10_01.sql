CREATE TABLE 家計簿 (
  日付        DATE,
  費目ID      INTEGER,
  メモ         VARCHAR(100),
  入金額      INTEGER,
  出金額      INTEGER
)