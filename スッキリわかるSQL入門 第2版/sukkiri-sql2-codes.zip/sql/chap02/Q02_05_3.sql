UPDATE 都道府県 SET 地域 = '九州', 面積 = 4976
 WHERE コード = '40'