UPDATE 家計簿
   SET 入金額 = 99999
 WHERE 日付 = '2018-02-03'
