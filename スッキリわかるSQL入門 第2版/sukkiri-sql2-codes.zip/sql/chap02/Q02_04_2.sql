INSERT INTO 都道府県
     VALUES ('37', '四国', '香川', '高松', 1876 )