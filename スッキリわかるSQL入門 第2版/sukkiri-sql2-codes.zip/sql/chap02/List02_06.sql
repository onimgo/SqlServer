SELECT 費目, 入金額, 出金額
  FROM 家計簿