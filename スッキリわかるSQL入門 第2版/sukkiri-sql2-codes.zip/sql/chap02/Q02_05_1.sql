UPDATE 都道府県 SET 県庁所在地 = '京都'
 WHERE コード = '26'