UPDATE 家計簿
   SET 入金額 = 99999