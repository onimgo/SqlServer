/* AND を使う場合 */
SELECT * FROM 気象観測
 WHERE 湿度 >= 60 AND 湿度 <= 79