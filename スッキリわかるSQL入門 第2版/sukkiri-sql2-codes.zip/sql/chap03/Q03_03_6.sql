DELETE FROM 成績表
 WHERE 法学 = 0
    OR 経済学 = 0
    OR 哲学 = 0
    OR 情報理論 = 0
    OR 外国語 = 0