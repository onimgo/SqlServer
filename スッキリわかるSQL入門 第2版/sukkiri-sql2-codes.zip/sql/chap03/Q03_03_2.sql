/* 学生1 */
INSERT INTO 成績表
     VALUES ('S001', '織田 信長', 77, 55, 80, 75, 93, NULL);
/* 学生2 */
INSERT INTO 成績表
     VALUES ('A002', '豊臣 秀吉', 64, 69, 70, 0, 59, NULL);
/* 学生3 */
INSERT INTO 成績表
     VALUES ('E003', '徳川 家康', 80, 83, 85, 90, 79, NULL);