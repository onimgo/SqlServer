SELECT * FROM 家計簿
 WHERE 費目 IN ('家賃','電気代','水道代')
