UPDATE 成績表 SET 外国語 = 81
 WHERE 学籍番号 IN ('A002', 'E003')