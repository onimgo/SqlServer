SELECT * FROM 気象観測
 WHERE 降水量 <= 100 AND 湿度 < 50