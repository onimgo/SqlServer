SELECT 都道府県名 FROM 都道府県
 WHERE 都道府県名 LIKE '%川'