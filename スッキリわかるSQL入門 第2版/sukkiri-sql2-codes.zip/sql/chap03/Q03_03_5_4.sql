UPDATE 成績表 SET 総合成績 = 'C'
 WHERE 総合成績 IS NULL