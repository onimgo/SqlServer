SELECT *
  FROM 家計簿
 WHERE メモ LIKE '%1月%'