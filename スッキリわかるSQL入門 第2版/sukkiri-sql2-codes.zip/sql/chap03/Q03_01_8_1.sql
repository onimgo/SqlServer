/* NOT IN を使う場合 */
SELECT * FROM 気象観測 WHERE 月 NOT IN (3, 5, 7)
