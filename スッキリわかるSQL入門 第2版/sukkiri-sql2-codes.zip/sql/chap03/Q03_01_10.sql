SELECT * FROM 気象観測
 WHERE 最低気温 < 5 OR 最高気温 > 35