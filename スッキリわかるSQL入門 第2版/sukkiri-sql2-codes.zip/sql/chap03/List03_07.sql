UPDATE 湊くんの買い物リスト
   SET 価格 = 6200
 WHERE 名称 = 'スッキリ勇者クエスト'
   AND 販売店 = 'B'