UPDATE 成績表 SET 法学 = 85, 哲学 = 67
 WHERE 学籍番号 = 'S001'