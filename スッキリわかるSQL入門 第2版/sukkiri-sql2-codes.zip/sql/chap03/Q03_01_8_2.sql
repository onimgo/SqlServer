/* AND を使う場合 */
SELECT * FROM 気象観測
 WHERE 月 <> 3 AND 月 <> 5 AND 月 <> 7