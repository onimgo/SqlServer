SELECT * FROM 家計簿
 WHERE メモ LIKE '%購入%' AND 出金額 > 0