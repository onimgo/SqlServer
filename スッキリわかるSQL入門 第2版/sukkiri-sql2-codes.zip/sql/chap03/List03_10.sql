DELETE FROM 社員
 WHERE 社員番号 = '2003031' /* 社員番号で対象行を特定*/