UPDATE 成績表 SET 総合成績 = 'A'
 WHERE 法学 >= 80 AND 経済学 >= 80 AND 哲学 >= 80
   AND 情報理論 >= 80 AND 外国語 >= 80