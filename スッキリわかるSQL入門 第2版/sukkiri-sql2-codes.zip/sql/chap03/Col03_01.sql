/* 「100を含む文字列」という意味になる */
SELECT * FROM 家計簿 WHERE メモ LIKE '%100%'
