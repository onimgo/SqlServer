SELECT * FROM 都道府県
 WHERE 都道府県名 = 県庁所在地