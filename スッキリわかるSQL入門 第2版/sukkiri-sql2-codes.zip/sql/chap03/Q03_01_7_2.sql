/* OR を使う場合 */
SELECT * FROM 気象観測
 WHERE 月 = 3 OR 月 = 5 OR 月 = 7