SELECT * FROM 家計簿
 WHERE 日付 = '2018-03-01' AND 費目 = '食費'
