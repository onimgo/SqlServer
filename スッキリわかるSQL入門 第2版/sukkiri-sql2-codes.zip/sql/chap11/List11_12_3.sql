-- 次の値に進み、その値を取得
SELECT NEXTVAL('費目シーケンス');