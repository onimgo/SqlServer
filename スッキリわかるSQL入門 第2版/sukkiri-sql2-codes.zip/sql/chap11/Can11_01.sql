CREATE INDEX 日付インデックス ON 家計簿(日付);
CREATE INDEX 費目IDインデックス ON 家計簿(費目ID);