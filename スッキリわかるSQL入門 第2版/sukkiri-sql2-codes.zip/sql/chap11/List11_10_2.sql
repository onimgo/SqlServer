-- 現在の値を取得
SELECT 費目シーケンス.CURRVAL FROM DUAL;