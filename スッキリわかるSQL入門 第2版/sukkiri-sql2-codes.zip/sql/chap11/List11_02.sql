SELECT * FROM 家計簿
 WHERE メモ = '不明'