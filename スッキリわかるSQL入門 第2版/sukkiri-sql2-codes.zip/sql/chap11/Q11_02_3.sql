INSERT INTO 学生
  (学籍番号, 名前, 生年月日, 血液型, 学部ID, 登録順)
VALUES
  ('B1101022', '古島 進', '1993-02-12', 'A', 'K', ISTD.NEXTVAL)