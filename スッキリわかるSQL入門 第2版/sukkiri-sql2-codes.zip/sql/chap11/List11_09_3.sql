/* PostgreSQL の場合 */
CREATE TABLE 費目 (
  ID SERIAL PRIMARY KEY,
  名前 VARCHAR(40)
)