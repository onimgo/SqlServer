-- シーケンスを作成
CREATE SEQUENCE 費目シーケンス;