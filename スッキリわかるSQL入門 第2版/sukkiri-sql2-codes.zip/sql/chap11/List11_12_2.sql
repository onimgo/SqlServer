-- 現在の値を取得
SELECT CURRVAL('費目シーケンス');