-- 次の値に進み、その値を取得
SELECT 費目シーケンス.NEXTVAL FROM DUAL;