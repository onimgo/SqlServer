INSERT INTO 費目 (ID, 名前)
     VALUES (費目IDシーケンス.NEXTVAL, '接待交際費')