INSERT INTO 家計簿 (出金額)
     VALUES (1000 + 105)