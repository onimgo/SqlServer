SELECT 出金額, ROUND(出金額, -2) AS 百円単位の出金額
  FROM 家計簿