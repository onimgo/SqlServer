UPDATE 受注
   SET 文字数 = LENGTH(REPLACE(文字,' ', ''))
