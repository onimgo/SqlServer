/* Oracle DB */
SELECT 式や関数 FROM DUAL
