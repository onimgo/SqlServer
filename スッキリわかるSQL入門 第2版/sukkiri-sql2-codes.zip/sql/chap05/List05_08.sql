SELECT メモ, LENGTH(メモ) AS メモの長さ FROM 家計簿
 WHERE LENGTH(メモ) <= 10
