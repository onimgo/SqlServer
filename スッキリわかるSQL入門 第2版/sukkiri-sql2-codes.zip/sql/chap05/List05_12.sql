SELECT CONCAT(費目, ':' || メモ) FROM 家計簿
