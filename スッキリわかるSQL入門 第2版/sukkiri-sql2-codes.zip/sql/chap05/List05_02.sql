SELECT 出金額,
       出金額 + 100 AS 百円増しの出金額
  FROM 家計簿
