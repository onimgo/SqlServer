SELECT メモ, TRIM(メモ) AS 空白除去したメモ
  FROM 家計簿
