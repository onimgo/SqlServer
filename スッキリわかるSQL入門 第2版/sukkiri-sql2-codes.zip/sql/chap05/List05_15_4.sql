SELECT COALESCE(NULL, NULL, 'C') /* 結果は 'C' */
