SELECT COALESCE('A', 'B', 'C') /* 結果は 'A' */
