UPDATE 試験結果
   SET 論述 = (68*4) - (65+53+70)
 WHERE 受験者ID = 'SW1350'