SELECT COALESCE(NULL, 'B', 'C') /* 結果は 'B' */
