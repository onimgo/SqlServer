INSERT INTO 家計簿
VALUES (CURRENT_DATE, '食費', 'ドーナツを買った', 0, 260)