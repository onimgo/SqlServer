UPDATE 試験結果
   SET 午前 = (56*4) - (59+56+36)
 WHERE 受験者ID = 'SW1877'