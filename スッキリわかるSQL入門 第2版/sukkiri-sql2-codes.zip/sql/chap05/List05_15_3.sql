SELECT COALESCE(NULL, 'B', NULL) /* 結果は 'B' */
