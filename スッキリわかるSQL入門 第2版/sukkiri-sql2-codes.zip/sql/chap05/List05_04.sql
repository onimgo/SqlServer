UPDATE 家計簿
   SET 出金額= 出金額 + 100