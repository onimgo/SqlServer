UPDATE 試験結果
   SET 午後1 = (80*4) - (86+68+91)
 WHERE 受験者ID = 'SW1046'