SELECT SUM(入金額), SUM(出金額) FROM 家計簿
