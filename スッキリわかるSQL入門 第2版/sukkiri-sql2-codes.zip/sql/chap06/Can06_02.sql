SELECT COUNT(費目) AS 食費を支払った回数 FROM 家計簿
 WHERE 費目 = '食費'
