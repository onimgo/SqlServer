SELECT AVG(入金額) AS 平均額 FROM 家計簿アーカイブ
 WHERE 費目 = '給料'