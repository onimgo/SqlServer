SELECT SUM(出金額) AS 出金額の合計
  FROM 家計簿